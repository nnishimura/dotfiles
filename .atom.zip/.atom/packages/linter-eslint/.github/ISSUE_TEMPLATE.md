## Issue Type
<!-- Can be "Bug", "Feature Request", "Question", etc.-->


## Issue Description
<!-- Describe what happened, what you think should have happened, and any other relevant details -->


## Bug Checklist
- [ ] Restart Atom
- [ ] Verify the `eslint` CLI gives the proper result, while `linter-eslint` does not
- [ ] Paste the output of the `Linter Eslint: Debug` command from the Command Palette below

```
Linter Eslint: Debug output here
```
