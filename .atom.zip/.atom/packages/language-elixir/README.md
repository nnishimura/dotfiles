# language-elixir package

[![Build Status](https://travis-ci.org/elixir-lang/language-elixir.svg?branch=master)](https://travis-ci.org/elixir-lang/language-elixir)

Elixir language support for Atom.

Adds syntax highlighting and snippets to Elixir files in Atom.

Copyright (c) 2014 [Plataformatec](http://plataformatec.com.br).
