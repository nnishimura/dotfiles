Here is a list of every people to thank, because without them, the package would not be what it is today.

- Tom Gerrits
- [Chris Normansell (@CWDN)](https://github.com/CWDN)
- [Guillaume Perréal (@Adirelle)](https://github.com/Adirelle)
- [Vincent Klaiber (@vinkla)](https://github.com/vinkla)
- [@Benoth](https://github.com/Benoth)
- [Axel Anceau (@Peekmo)](https://github.com/Peekmo)

And **you** who are using the plugin and reporting issues ;)

Thanks to everyone.
