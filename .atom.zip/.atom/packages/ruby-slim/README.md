# ruby-slim package

Slim support for Atom.
