# CHANGELOG

## TODO

*   Optimize enabler
*   Cursor position
*   More optimization ?

## 1.0.0 - Complete description

*   Add description to package.json

## 1.0.0 - First Release

*   Add descrption to README.md
*   Publish to Atom

## 0.1.2 - Prepare First Release

*   Add return error statement

## 0.1.1 - Prepare First Release

*   Fix enabler

## 0.1.0 - Prepare First Release

*   Every feature added
*   Every bug fixed
