"""Some."""
from os import path


def main():
    """Some docstring."""
    if path.exists('/tmp'):
        return True




if __name__ == '__main__':
    main()
