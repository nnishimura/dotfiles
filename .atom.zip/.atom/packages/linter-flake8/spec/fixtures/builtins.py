foo = bar
foobar = foo_bar
