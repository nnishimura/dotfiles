# auto-encoding

default "Auto Detect".

## Installation

`$ apm install auto-encoding`
