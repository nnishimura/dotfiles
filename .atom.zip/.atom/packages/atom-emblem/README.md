# atom-emblem package

[Emblem](http://emblemjs.com/) language for Atom

![Emblem](https://raw.githubusercontent.com/zb3k/atom-emblem/master/screenshot.png)

Originally converted from the [Sublime Text package](https://github.com/johanobergman/sublime-emblem-syntax) and adapted for Atom.
